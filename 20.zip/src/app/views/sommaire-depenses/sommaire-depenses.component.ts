import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sommaire-depenses',
  templateUrl: './sommaire-depenses.component.html',
  styleUrls: ['./sommaire-depenses.component.sass']
})
export class SommaireDepensesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
