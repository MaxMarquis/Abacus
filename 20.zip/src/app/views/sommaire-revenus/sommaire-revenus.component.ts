import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sommaire-revenus',
  templateUrl: './sommaire-revenus.component.html',
  styleUrls: ['./sommaire-revenus.component.sass']
})
export class SommaireRevenusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
