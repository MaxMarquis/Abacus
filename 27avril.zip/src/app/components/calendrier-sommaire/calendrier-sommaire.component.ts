import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calendrier-sommaire',
  templateUrl: './calendrier-sommaire.component.html',
  styleUrls: ['./calendrier-sommaire.component.sass']
})
export class CalendrierSommaireComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
