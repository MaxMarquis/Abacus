import { SortByDatesPipe } from './sort-by-dates.pipe';

describe('SortByDatesPipe', () => {
  it('create an instance', () => {
    const pipe = new SortByDatesPipe();
    expect(pipe).toBeTruthy();
  });
});
