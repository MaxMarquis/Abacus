import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calendrier',
  templateUrl: './calendrier.component.html',
  styleUrls: ['./calendrier.component.sass']
})
export class CalendrierComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
