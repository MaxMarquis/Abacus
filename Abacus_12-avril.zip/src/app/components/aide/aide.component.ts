import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aide',
  templateUrl: './aide.component.html',
  styleUrls: ['./aide.component.sass']
})
export class AideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
