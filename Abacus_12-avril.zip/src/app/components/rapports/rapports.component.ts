import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rapports',
  templateUrl: './rapports.component.html',
  styleUrls: ['./rapports.component.sass']
})
export class RapportsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
