export class Details {
    id!: string;
    description!: string;
    montant!: number;
    date!: Date;
}