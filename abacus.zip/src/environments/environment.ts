

export const environment = {
    production: false,
    storageIncomeKey: "income",
    storageExpenseKey: "expense"
  };
  
