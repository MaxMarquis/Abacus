export const environment = {
    production: true,
    storageIncomeKey: "income",
    storageExpenseKey: "expense"
  };
  