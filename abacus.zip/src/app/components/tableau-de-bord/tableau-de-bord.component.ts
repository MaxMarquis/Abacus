import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tableau-de-bord',
  templateUrl: './tableau-de-bord.component.html',
  styleUrls: ['./tableau-de-bord.component.sass']
})
export class TableauDeBordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
